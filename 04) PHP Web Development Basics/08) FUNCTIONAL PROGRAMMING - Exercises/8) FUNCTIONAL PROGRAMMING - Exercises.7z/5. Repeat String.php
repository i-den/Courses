<?php

$input = 'Hello, there! ';
$numOfRepets = 3;

echo str_repeat($input, $numOfRepets);
