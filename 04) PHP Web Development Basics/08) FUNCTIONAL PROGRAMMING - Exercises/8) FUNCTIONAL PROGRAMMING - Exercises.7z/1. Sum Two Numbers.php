<?php

$sumTwoNum = function ($firstNum, $secNum) {
  return $firstNum + $secNum;
};

echo 'The sum is ' . $sumTwoNum(7.1234, 7.4321);
